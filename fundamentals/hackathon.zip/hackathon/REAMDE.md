# Ninja Options ~ |S0|
    ++ player is Ninja
        - press 1 if you want to throw a knife/shurirken - give random chance to hit BUT higher damange
        - press 2 for knife = less damage
        - press 3 sneak attack - random low chance to work
        - press 4 eat sushi - gain 10 health but - reduce speed -5
        [S3]~start w/ 3? sushi
        [S2] ~if speed < 10; sneak fails

# Pirate Options ~ |SO|
    ++ Pirate does random d4 for attack 
        - 1 shoot flintlock - give random chance to hit BUT higher damange
        - 2 for cutlass = less damage
        - 3 peg leg breaks - random low chance fall
        - 4 drink rum - gain 15 health but -2 for shoot flintlock
            ~start w/ 3? drinks of rum


# Extras: ~ |S3-S4|
    - More characters
        Black Beard
        - Boss fight if you beat pirate ~ blackbeard
        - Stats reset
        - higher chance of success, higher damage

# Assignments:
    - Tristan: Ninja
    - Eric: Pirate
    - Alex: Input selection & action creation

